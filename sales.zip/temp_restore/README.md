# AstryxNodes Sales Management System

A modern sales tracking application with authentication, built with Node.js and Express.

## Features

- User authentication (registration and login)
- Sales management with CRUD operations
- Monthly sales filtering
- Automatic expiry date calculation
- Plan-based auto-fill for server specifications
- Renewal functionality for subscriptions
- Salary distribution calculations
- VPS expenses tracking
- Nebula-themed modern UI
- Mobile-responsive design

## Local Development

```bash
npm install
npm start
```

The server will run on port 3020 (or the port specified in the PORT environment variable).

## Docker

The app ships with a `Dockerfile` and `docker-compose.yml`. SQLite is stored on a named volume (`sales-db`) mounted at `/app/data`, so data survives rebuilds and restarts.

### Quick start (docker compose)

1. Copy the env template and set a real secret:
   ```bash
   cp .env.example .env
   # edit .env and set SESSION_SECRET to a long random string
   ```
2. Build and run:
   ```bash
   docker compose up -d --build
   ```
3. The app is available at `http://localhost:3020` (or `$PORT` if set in `.env`).

Useful commands:
```bash
docker compose logs -f sales-app   # tail logs
docker compose down                # stop (keeps the sales-db volume)
docker compose down -v             # stop and delete stored data
```

### Plain Docker (no compose)

```bash
docker build -t astryxnodes-sales-app .
docker run -d \
  --name astryxnodes-sales-app \
  -p 3020:3020 \
  -e SESSION_SECRET=change-me-to-a-long-random-string \
  -v sales-db:/app/data \
  astryxnodes-sales-app
```

### Environment variables

| Variable          | Default                 | Notes                                          |
|--------------------|--------------------------|-------------------------------------------------|
| `PORT`             | `3020`                  | Port the server listens on inside the container |
| `SESSION_SECRET`   | *(required in compose)* | Used to sign the session cookie                 |
| `DATABASE_PATH`    | `/app/data/sales.db`    | Points at the mounted volume                    |
| `SALES_API_KEY`    | *(optional)*             | For automated order creation, if used            |

The container runs as a non-root user and exposes a health check against `/api/session`.

## Vercel Deployment

### Important Notes:

⚠️ **SQLite Database Limitation**: SQLite uses file-based storage which may not persist properly on Vercel's serverless environment. Consider using:
- Vercel Postgres (recommended)
- MongoDB Atlas
- Supabase
- PlanetScale

**If you see "SQLITE_CORRUPT" or "database disk image is malformed"**: The app now automatically removes a corrupt database file and creates a fresh one on startup. On Vercel, `/tmp` is ephemeral, so data can be lost between deploys or cold starts. For reliable production data, use a hosted database (e.g. Vercel Postgres, Turso, Supabase).

### Deployment Steps:

1. Install Vercel CLI:
```bash
npm i -g vercel
```

2. Login to Vercel:
```bash
vercel login
```

3. Deploy:
```bash
vercel
```

4. For production deployment:
```bash
vercel --prod
```

### Environment Variables:

Set these in Vercel dashboard:
- `NODE_ENV=production`
- `SESSION_SECRET` (change from default)

### Database Migration:

If using SQLite on Vercel, the database file will be recreated on each deployment. Consider migrating to a cloud database for production use.

## Project Structure

```
sales/
├── server.js          # Main server file
├── public/            # Frontend files
│   ├── index.html
│   ├── styles.css
│   └── app.js
├── sales.db          # SQLite database (not in git)
├── package.json
└── vercel.json       # Vercel configuration
```

## Default Port

- Local: 3020
- Vercel: Uses Vercel's provided PORT
