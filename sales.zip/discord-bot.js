'use strict';

const {
  Client,
  EmbedBuilder,
  Events,
  GatewayIntentBits,
  SlashCommandBuilder,
} = require('discord.js');

const SETTING_DEFAULTS = Object.freeze({
  bot_token: '',
  guild_id: '',
  channel_id: '',
  webhook_url: '',
  expiring_days: '7',
  notify_sales: 'true',
  notify_renewals: 'true',
  notify_expiring: 'true',
});

const SETTING_KEYS = Object.freeze(Object.keys(SETTING_DEFAULTS));

let activeClient = null;
let activeDatabase = null;
let botStatus = {
  status: 'not_configured',
  user: 'Not configured',
  guild: '',
  error: '',
};

function dbRun(db, sql, params = []) {
  return new Promise((resolve, reject) => {
    db.run(sql, params, function onRun(error) {
      if (error) return reject(error);
      resolve({ lastID: this.lastID, changes: this.changes });
    });
  });
}

function dbGet(db, sql, params = []) {
  return new Promise((resolve, reject) => {
    db.get(sql, params, (error, row) => {
      if (error) return reject(error);
      resolve(row || null);
    });
  });
}

function dbAll(db, sql, params = []) {
  return new Promise((resolve, reject) => {
    db.all(sql, params, (error, rows) => {
      if (error) return reject(error);
      resolve(rows || []);
    });
  });
}

function ensureSettingsTable(db, callback) {
  db.run(
    `CREATE TABLE IF NOT EXISTS discord_settings (
      key TEXT PRIMARY KEY,
      value TEXT NOT NULL DEFAULT ''
    )`,
    (createError) => {
      if (createError) return callback(createError);

      const statement = db.prepare(
        'INSERT OR IGNORE INTO discord_settings (key, value) VALUES (?, ?)'
      );
      for (const [key, value] of Object.entries(SETTING_DEFAULTS)) {
        statement.run(key, value);
      }
      statement.finalize(callback);
    }
  );
}

async function getDiscordSettings(db) {
  const rows = await dbAll(db, 'SELECT key, value FROM discord_settings');
  const settings = { ...SETTING_DEFAULTS };
  for (const row of rows) {
    if (Object.prototype.hasOwnProperty.call(SETTING_DEFAULTS, row.key)) {
      settings[row.key] = String(row.value ?? '');
    }
  }
  return settings;
}

async function setDiscordSetting(db, key, value) {
  if (!SETTING_KEYS.includes(key)) {
    throw new Error(`Unsupported Discord setting: ${key}`);
  }
  await dbRun(
    'INSERT INTO discord_settings (key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value',
    [key, String(value ?? '')]
  );
}

function isEnabled(value) {
  return String(value).toLowerCase() === 'true';
}

function safeText(value, maxLength = 1024) {
  return String(value ?? 'N/A')
    .replace(/([*_`~|])/g, '\\$1')
    .replace(/[\r\n]+/g, ' ')
    .slice(0, maxLength);
}

function money(value) {
  const amount = Number(value);
  if (!Number.isFinite(amount)) return '₱0.00';
  return `₱${amount.toLocaleString('en-PH', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
}

function buildSaleEmbed(type, sale) {
  const isRenewal = type === 'renewal';
  const embed = new EmbedBuilder()
    .setColor(isRenewal ? 0x4c7bfa : 0x34c98f)
    .setTitle(isRenewal ? 'Subscription Renewed' : 'New Sale Recorded')
    .setDescription('AstryxHosting sales notification')
    .addFields(
      { name: 'Customer', value: safeText(sale.customer_name, 256), inline: true },
      { name: 'Plan', value: safeText(sale.plan, 256), inline: true },
      { name: 'Amount', value: money(sale.amount), inline: true },
      { name: 'Payment', value: safeText(sale.payment_method, 128), inline: true },
      { name: 'Status', value: safeText(sale.status || 'Paid', 32), inline: true },
      { name: 'Date Bought', value: safeText(sale.date_bought, 64), inline: true }
    )
    .setTimestamp(new Date());

  if (sale.date_expiry) {
    embed.addFields({ name: 'Expires', value: safeText(sale.date_expiry, 64), inline: true });
  }
  if (sale.promo) {
    embed.addFields({ name: 'Promo', value: safeText(sale.promo, 128), inline: true });
  }
  return embed;
}

function buildExpiryEmbed(sales, days) {
  const embed = new EmbedBuilder()
    .setColor(sales.length ? 0xe6a53a : 0x34c98f)
    .setTitle('Subscription Expiry Digest')
    .setDescription(
      sales.length
        ? `${sales.length} subscription(s) expire within the next ${days} day(s).`
        : `No subscriptions expire within the next ${days} day(s).`
    )
    .setTimestamp(new Date());

  for (const sale of sales.slice(0, 20)) {
    embed.addFields({
      name: `${safeText(sale.customer_name, 180)} · ${safeText(sale.plan, 120)}`,
      value: `Expiry: ${safeText(sale.date_expiry, 32)} | ${money(sale.amount)} | ${safeText(sale.status, 24)}`,
      inline: false,
    });
  }
  if (sales.length > 20) {
    embed.setFooter({ text: `Showing 20 of ${sales.length} subscriptions` });
  }
  return embed;
}

async function sendEmbed(settings, embed) {
  if (settings.webhook_url) {
    let url;
    try {
      url = new URL(settings.webhook_url);
    } catch {
      throw new Error('The Discord webhook URL is invalid.');
    }

    const allowedHosts = new Set([
      'discord.com',
      'discordapp.com',
      'canary.discord.com',
      'ptb.discord.com',
    ]);
    if (
      url.protocol !== 'https:' ||
      !allowedHosts.has(url.hostname.toLowerCase()) ||
      !/^\/(api\/)?webhooks\//.test(url.pathname) ||
      url.username ||
      url.password
    ) {
      throw new Error('The Discord webhook URL is invalid.');
    }

    const response = await fetch(url.toString(), {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ embeds: [embed.toJSON()] }),
    });
    if (!response.ok) {
      const detail = await response.text().catch(() => '');
      throw new Error(`Discord webhook returned ${response.status}${detail ? `: ${detail.slice(0, 180)}` : ''}`);
    }
    return;
  }

  if (!activeClient || !activeClient.isReady()) {
    throw new Error('Discord bot is not connected.');
  }
  if (!settings.channel_id) {
    throw new Error('Set a notification channel ID or configure a webhook URL.');
  }

  const channel = await activeClient.channels.fetch(settings.channel_id);
  if (!channel || !channel.isTextBased() || typeof channel.send !== 'function') {
    throw new Error('The configured Discord channel is unavailable or cannot receive messages.');
  }
  await channel.send({ embeds: [embed] });
}

async function sendCommandReply(interaction, content) {
  const safeContent = String(content).slice(0, 1900);
  if (interaction.deferred || interaction.replied) {
    await interaction.editReply({ content: safeContent });
  } else {
    await interaction.reply({ content: safeContent, ephemeral: true });
  }
}

function parseMonth(month) {
  if (!month) return null;
  return /^\d{4}-(0[1-9]|1[0-2])$/.test(month) ? month : null;
}

async function handleCommand(interaction, db, settings) {
  const month = parseMonth(interaction.options.getString('month'));
  const days = Math.min(Math.max(interaction.options.getInteger('days') || 7, 1), 90);

  if (interaction.commandName === 'stats') {
    const where = month ? 'WHERE strftime("%Y-%m", date_bought) = ?' : '';
    const params = month ? [month] : [];
    const row = await dbGet(db, `
      SELECT COUNT(*) AS total_sales,
             COALESCE(SUM(amount), 0) AS total_amount,
             COALESCE(SUM(CASE WHEN status = 'Paid' THEN amount ELSE 0 END), 0) AS paid_amount,
             COALESCE(SUM(CASE WHEN status = 'Pending' THEN amount ELSE 0 END), 0) AS pending_amount
      FROM sales ${where}
    `, params);
    const label = month || 'All time';
    return sendCommandReply(
      interaction,
      `**Sales (${label})**\nTransactions: ${row.total_sales}\nTotal: ${money(row.total_amount)}\nPaid: ${money(row.paid_amount)}\nPending: ${money(row.pending_amount)}`
    );
  }

  if (interaction.commandName === 'revenue') {
    const where = month
      ? "WHERE status = 'Paid' AND strftime('%Y-%m', date_bought) = ?"
      : "WHERE status = 'Paid'";
    const rows = await dbAll(db, `
      SELECT payment_method, COALESCE(SUM(amount), 0) AS total
      FROM sales ${where}
      GROUP BY payment_method
      ORDER BY total DESC
    `, month ? [month] : []);
    const lines = rows.length
      ? rows.map((row) => `${safeText(row.payment_method, 80)}: ${money(row.total)}`).join('\n')
      : 'No paid sales found.';
    return sendCommandReply(interaction, `**Paid revenue (${month || 'All time'})**\n${lines}`);
  }

  if (interaction.commandName === 'expiring') {
    const today = new Date().toISOString().slice(0, 10);
    const end = new Date(`${today}T00:00:00.000Z`);
    end.setUTCDate(end.getUTCDate() + days);
    const endDate = end.toISOString().slice(0, 10);
    const rows = await dbAll(db, `
      SELECT customer_name, plan, date_expiry, amount, status
      FROM sales
      WHERE date_expiry BETWEEN ? AND ? AND COALESCE(no_renew, 0) = 0
      ORDER BY date_expiry ASC
      LIMIT 20
    `, [today, endDate]);
    const lines = rows.length
      ? rows.map((row) => `${safeText(row.customer_name, 80)} · ${safeText(row.plan, 80)} · ${row.date_expiry}`).join('\n')
      : `No subscriptions expire in the next ${days} day(s).`;
    return sendCommandReply(interaction, `**Expiring subscriptions**\n${lines}`);
  }

  if (interaction.commandName === 'plans') {
    const rows = await dbAll(db, 'SELECT name, cpu, ram, disk, amount FROM plans ORDER BY amount ASC LIMIT 20');
    const lines = rows.length
      ? rows.map((row) => `**${safeText(row.name, 100)}** · ${safeText(row.cpu, 40)} CPU · ${safeText(row.ram, 30)} RAM · ${safeText(row.disk, 30)} Disk · ${money(row.amount)}`).join('\n')
      : 'No plans are configured.';
    return sendCommandReply(interaction, `**Available plans**\n${lines}`);
  }

  return sendCommandReply(interaction, 'Unknown command.');
}

function getSlashCommands() {
  return [
    new SlashCommandBuilder()
      .setName('stats')
      .setDescription('View sales totals and payment status')
      .addStringOption((option) => option.setName('month').setDescription('Month in YYYY-MM format').setRequired(false)),
    new SlashCommandBuilder()
      .setName('revenue')
      .setDescription('View paid revenue grouped by payment method')
      .addStringOption((option) => option.setName('month').setDescription('Month in YYYY-MM format').setRequired(false)),
    new SlashCommandBuilder()
      .setName('expiring')
      .setDescription('List subscriptions expiring soon')
      .addIntegerOption((option) => option.setName('days').setDescription('Number of days to check').setMinValue(1).setMaxValue(90).setRequired(false)),
    new SlashCommandBuilder()
      .setName('plans')
      .setDescription('List the configured hosting plans'),
  ].map((command) => command.toJSON());
}

async function startDiscordBot(db) {
  activeDatabase = db;

  if (activeClient) {
    const previousClient = activeClient;
    activeClient = null;
    try {
      previousClient.destroy();
    } catch (error) {
      console.warn('Could not cleanly stop the previous Discord client:', error.message);
    }
  }

  let settings;
  try {
    settings = await getDiscordSettings(db);
  } catch (error) {
    botStatus = { status: 'error', user: 'Unavailable', guild: '', error: error.message };
    throw error;
  }

  if (!settings.bot_token && settings.webhook_url) {
    botStatus = { status: 'online', user: 'Webhook notifications', guild: '', error: '' };
    return botStatus;
  }

  if (!settings.bot_token) {
    botStatus = { status: 'not_configured', user: 'Not configured', guild: '', error: '' };
    return botStatus;
  }

  botStatus = { status: 'connecting', user: 'Connecting…', guild: settings.guild_id || '', error: '' };
  const client = new Client({ intents: [GatewayIntentBits.Guilds] });
  activeClient = client;

  client.once(Events.ClientReady, async (readyClient) => {
    botStatus = {
      status: 'online',
      user: readyClient.user.tag,
      guild: settings.guild_id || '',
      error: '',
    };

    if (settings.guild_id) {
      try {
        await readyClient.application.commands.set(getSlashCommands(), settings.guild_id);
      } catch (error) {
        botStatus.error = `Connected, but slash command registration failed: ${error.message}`;
        console.error('Discord slash command registration failed:', error.message);
      }
    }
  });

  client.on(Events.InteractionCreate, async (interaction) => {
    if (!interaction.isChatInputCommand()) return;
    try {
      await handleCommand(interaction, activeDatabase, settings);
    } catch (error) {
      console.error('Discord command failed:', error.message);
      await sendCommandReply(interaction, 'The command failed. Check the sales app logs for details.').catch(() => {});
    }
  });

  client.on(Events.Error, (error) => {
    botStatus = { ...botStatus, status: 'error', error: error.message };
    console.error('Discord client error:', error.message);
  });

  try {
    await client.login(settings.bot_token);
  } catch (error) {
    botStatus = { status: 'error', user: 'Connection failed', guild: settings.guild_id || '', error: error.message };
    activeClient = null;
    client.destroy();
    throw error;
  }

  return botStatus;
}

async function notifyDiscord(db, type, sale) {
  const settings = await getDiscordSettings(db);
  if (type === 'sale' && !isEnabled(settings.notify_sales)) return false;
  if (type === 'renewal' && !isEnabled(settings.notify_renewals)) return false;
  if (!settings.webhook_url && (!settings.bot_token || !settings.channel_id)) return false;

  await sendEmbed(settings, buildSaleEmbed(type, sale));
  return true;
}

async function sendExpiryDigest(db) {
  const settings = await getDiscordSettings(db);
  if (!isEnabled(settings.notify_expiring)) return false;
  if (!settings.webhook_url && (!settings.bot_token || !settings.channel_id)) return false;

  const days = Math.min(Math.max(parseInt(settings.expiring_days, 10) || 7, 1), 90);
  const start = new Date();
  start.setHours(0, 0, 0, 0);
  const end = new Date(start);
  end.setDate(end.getDate() + days);
  const startDate = start.toISOString().slice(0, 10);
  const endDate = end.toISOString().slice(0, 10);
  const sales = await dbAll(db, `
    SELECT customer_name, plan, date_expiry, amount, status
    FROM sales
    WHERE date_expiry BETWEEN ? AND ? AND COALESCE(no_renew, 0) = 0
    ORDER BY date_expiry ASC
  `, [startDate, endDate]);

  await sendEmbed(settings, buildExpiryEmbed(sales, days));
  return true;
}

function getBotStatus() {
  return { ...botStatus };
}

module.exports = {
  SETTING_KEYS,
  ensureSettingsTable,
  getDiscordSettings,
  setDiscordSetting,
  startDiscordBot,
  notifyDiscord,
  sendExpiryDigest,
  getBotStatus,
};
